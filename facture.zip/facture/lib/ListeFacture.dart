
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:todo_app/user.dart';

import 'package:cached_network_image/cached_network_image.dart';
import 'factureFormulaire.dart';
import 'userDataBase.dart';

class ListeFacture extends StatelessWidget {


  const ListeFacture({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Liste des factures'),
      ),
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text('Drawer Header'),
            ),
            ListTile(
              leading: Icon(Icons.person,color: Colors.black,),
              title: Text('Ajouter un client',style: TextStyle(color: Colors.black),),
              onTap: () {
                // Update the state of the app.
                // ...
              },
            ),
              ListTile(
                leading: Icon(Icons.fact_check,color: Colors.black,),
                title: Text('Ajouter une facture',style: TextStyle(color: Colors.black),),
                onTap: () {
                  // Update the state of the app.
                  // ...
                },
              ),
        ]),
      ),
      body: FutureBuilder<List<User>>(
        future: UserDatabase.db.users(),
        builder: (BuildContext context, AsyncSnapshot<List<User>> snapshot) {
          if (snapshot.hasData){
            List<User>? users = snapshot.data;
            return ListView.builder(
                itemCount: users!.length,
                itemBuilder: (context, index){
                  return UserWidget(user: users[index]);
                }
            );
          }else{
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
      floatingActionButton: FloatingActionButton(onPressed: (){
        Navigator.push(context, MaterialPageRoute(builder: (context)=>FactureFormulaire()));
      },
        child:Icon(Icons.add),),
    );
  }
}


class UserWidget extends StatelessWidget {
  const UserWidget({Key? key, required this.user}) : super(key: key);
  final User user;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Navigator.push(context, MaterialPageRoute(
            builder: (context)=> UserPage(user)
        ));
      },
      child: Card(
        margin: EdgeInsets.all(8),
        elevation: 8,
        child: Row(
          children: [
            CachedNetworkImage(
              imageUrl: user.picture,
              placeholder: (context, url) =>
                  Center(child: CircularProgressIndicator()),
              errorWidget: (context, url, error) => Icon(Icons.error),
              width: 100,
              height: 100,
              fit: BoxFit.cover,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(user.firstname,
                      style:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                ),
                Text(user.mail,
                    style: TextStyle(color: Colors.grey[500], fontSize: 16))
              ],
            ),
            IconButton(
              padding: const EdgeInsets.only(left: 20.0),
              onPressed: () { UserDatabase.db.deleteUser(user.mail);},
              icon: const Icon(Icons.delete, color: Colors.red,),

            )
          ],
        ),
      ),
    );

  }
}



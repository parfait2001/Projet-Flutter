
import 'package:flutter/material.dart';

const kBlackBackColor = Color(0xFF202020);
const kPrimaryColor =  Color(0xFFFFBD73);
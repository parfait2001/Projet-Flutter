import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:todo_app/ListeFacture.dart';

import 'constant.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Auth Screen',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: kPrimaryColor,
        textTheme:TextTheme(headline4: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,
        ),
        button: TextStyle(color: kPrimaryColor),
          headline1:TextStyle(color: Colors.white,fontWeight: FontWeight.normal)
        )
      ),
      home: WelcomeScreen()
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
          Expanded(
            flex: 3,
            child:Container(decoration : BoxDecoration(
              image:DecorationImage(image:AssetImage("images/accueil.png"),
                fit: BoxFit.contain
              ),
          ),
          ),
          ),
          Expanded(
            child:Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
            RichText(
              textAlign: TextAlign.center,
              text: TextSpan(children:[
              TextSpan(
              text: "Facture App\n",
              style: Theme.of(context).textTheme.headline4?.copyWith(fontWeight:FontWeight.bold),
            ),
            TextSpan(
              text: "Faites votre facture en un click",
              style: Theme.of(context).textTheme.headline5,

            )
            ],
            ),
            ),
            FittedBox(
              child: Container(
                margin: EdgeInsets.only(bottom: 25),
                padding: EdgeInsets.symmetric(horizontal: 26,vertical: 16),
                decoration:BoxDecoration(borderRadius: BorderRadius.circular(25),
              color: kPrimaryColor,),
              child: Row(children: [
                GestureDetector(
                  onTap:(){Navigator.push(context, MaterialPageRoute(builder: (context)=>ListeFacture()));},
                  child: Text(("DEMARRER"),
                  style: Theme.of(context).textTheme.button?.copyWith(color: Colors.black),
                  ),
                ),
                SizedBox(height:10,),
                Icon(Icons.arrow_forward,color: Colors.black,)
              ],
              ),
              ),
            )
          ],
          ),
          )
        ],),
    );
  }
}



class User {
  String firstname;
  String lastname;
  String structureName;
  String adress;
  int phone;
  String date;
  String price;
  String picture;
  String service;
  String mail;

  User(this.firstname, this.lastname, this.mail, this.structureName, this.adress,
      this.phone, this.date, this.price, this.picture, this.service);

  Map<String, dynamic> toMap() {
    return {
      'firstname': firstname,
      'lastname': lastname,
      'mail': mail,
      'structureName': structureName,
      'adress': adress,
      'phone': phone,
      'date': date,
      'price': price,
      'picture': picture,
      'service': service
    };
  }

  factory User.fromMap(Map<String, dynamic> map) => new User(
        map['firstname'],
        map['lastname'],
        map['mail'],
        map['strucutreName'],
        map['adress'],
        map['phone'],
        map['date'],
        map['price'],
        map['picture'],
        map['service'],
      );
}

import 'package:flutter/widgets.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'user.dart';

class UserDatabase {
  UserDatabase._();

  static final UserDatabase db = UserDatabase._();
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await initDB();
    return _database!;
  }

  initDB() async {
    WidgetsFlutterBinding.ensureInitialized();
    return await openDatabase(
      join(await getDatabasesPath(), 'individus.db'),
      onCreate: (db, version) {
        return db.execute(
            "CREATE TABLE user(mail TEXT PRIMARY KEY, firstname TEXT, lastname TEXT, birthday TEXT, adress TEXT, phone INTEGER, gender TEXT, picture TEXT, citation TEXT)");
      },
      version: 1,
    );
  }

  void insertUser(User user) async {
    final Database db = await database;

    await db.insert(
      'user',
      user.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  void updateUser(User user) async {
    final Database db = await database;
    await db.update("user", user.toMap(), where: "mail = ?", whereArgs: [user.mail]);
  }

  void deleteUser(String mail) async {
    final db = await database;
    db.delete("user", where: "mail = ?", whereArgs: [mail]);
  }

  Future<List<User>> users() async {
    final Database db = await database;
    final List<Map<String, dynamic>> maps = await db.query('user');
    List<User> users = List.generate(maps.length, (i) {
      return User.fromMap(maps[i]);
    });

    if (users.isEmpty){
      for (User user in default_individus) {
        insertUser(user);
      }
      users = default_individus;
    }

    return users;
  }

  final List<User> default_individus = [ User(
            "John",
            "Doe",
      "johndoe@exemple.com",
            "01/01/01",
            "Cotonou, h1234",
            12345678,
            "male",
            "images/profil.png",
            "Black is my happy color"),
         User(
            "Jane",
            "Doe",
            "02/02/02",
            "Cotonou, h1234",
            12345679,
            "janedoe@exemple.com",
            "female",
            "images/picProfile.jpg",
            "White is my happy color"),
         User(
            "Joe",
            "Doe",
            "12/12/12",
            "Cotonou, h1234",
            12345689,
            "joedoe@exemple.com",
            "male",
            "images/profil.png",
            "Grey is my happy color")

  ];
}

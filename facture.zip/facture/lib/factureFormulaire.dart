
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'user.dart';

class FactureFormulaire extends StatefulWidget {
  const FactureFormulaire({Key? key}) : super(key: key);

  @override
  State<FactureFormulaire> createState() => _FactureFormulaireState();
}

class _FactureFormulaireState extends State<FactureFormulaire> {

  final formKey = GlobalKey<FormState>();
  final firstnameController = TextEditingController();
  final lastnameController = TextEditingController();
  final structureNameController = TextEditingController();
  final adressController = TextEditingController();
  final dateController = TextEditingController();
  final phoneController = TextEditingController();
  final genderController = TextEditingController();
  final serviceController = TextEditingController();
  final mailController = TextEditingController();


  @override
  void dispose() {
    firstnameController.dispose();
    lastnameController.dispose();
    structureNameController.dispose();
    adressController.dispose();
    phoneController.dispose();
    dateController.dispose();
    serviceController.dispose();
    mailController.dispose();
    super.dispose();
  }
  static const String picture = "images/profil.png";


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Facture"),
      ),
      body: Form(
        key: formKey,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.only(
                  top: 16.0, left: 16.0, right: 16.0, bottom: 8.0
              ),
              child: TextFormField(
                controller: firstnameController,
                decoration: InputDecoration(
                    icon: Icon(Icons.person),
                    labelText: 'Firstname',
                    hintText: 'Insert your FirstName'
                ),
                validator: (String? value){
                  return (value == null || value == "") ? 'Ce champ est obligatoire' : null;
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 8.0, left: 16.0, right: 16.0, bottom: 8.0
              ),
              child: TextFormField(
                controller: lastnameController,
                decoration: InputDecoration(
                    icon: Icon(Icons.person),
                    labelText: 'Lastname',
                    hintText: 'Insert your LastName'
                ),
                validator: (String? value){
                  return (value == null || value == "") ? 'Ce champ est obligatoire' : null;
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 8.0, left: 16.0, right: 16.0, bottom: 8.0
              ),
              child: TextFormField(
                controller:mailController,
                decoration: InputDecoration(
                    icon: Icon(Icons.person),
                    labelText: 'Email',
                    hintText: 'Insert your adress mail'
                ),
                validator: (String? value){
                  return (value == null || value == "") ? 'Ce champ est obligatoire' : null;
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 8.0, left: 16.0, right: 16.0, bottom: 8.0
              ),
              child: TextFormField(
                controller: structureNameController,
                decoration: InputDecoration(
                    icon: Icon(Icons.home),
                    labelText: 'Structure Name',
                    hintText: 'Your structure name'
                ),
                validator: (String? value){
                  return (value == null || value == "") ? 'Ce champ est obligatoire' : null;
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 8.0, left: 16.0, right: 16.0, bottom: 8.0
              ),
              child: TextFormField(
                controller: dateController,
                decoration: InputDecoration(
                    icon: Icon(Icons.date_range),
                    labelText: 'Date',
                    hintText: '01/01/22'
                ),
                validator: (String? value){
                  return (value == null || value == "") ? 'Ce champ est obligatoire' : null;
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 8.0, left: 16.0, right: 16.0, bottom: 8.0
              ),
              child: TextFormField(
                controller: adressController,
                decoration: InputDecoration(
                    labelText: 'adress',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20.0))
                    )
                ),
                validator: (String? value){
                  return (value == null || value == "") ? 'Ce champ est obligatoire' : null;
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 8.0, left: 16.0, right: 16.0, bottom: 8.0
              ),
              child: TextFormField(
                controller: phoneController,
                decoration: InputDecoration(
                    icon: Icon(Icons.phone),
                    labelText: 'Mobile Phone',
                    hintText: '65010101'
                ),
                validator: (String? value){
                  return (value == null || value == "") ? 'Ce champ est obligatoire' : null;
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  top: 8.0, left: 16.0, right: 16.0, bottom: 8.0
              ),
              child: TextFormField(
                controller: serviceController,
                decoration: InputDecoration(
                    icon: Icon(Icons.today_outlined),
                    labelText: 'Service',
                    hintText: 'Gâteau au chocolat'
                ),
                keyboardType: TextInputType.name,
                validator: (String? value){
                  return (value == null || value == "") ? 'Ce champ est obligatoire' : null;
                },
              ),
            ),
            SizedBox(height: 8.0),
            Center(
              child: ElevatedButton(
                onPressed: (){
                  if(formKey.currentState!.validate()){
                    var number = int.parse(phoneController.value.text);
                    User user = User(
                        firstnameController.value.text,
                        lastnameController.value.text,
                        structureNameController.value.text,
                        mailController.value.text,
                        adressController.value.text,
                        number,
                        dateController.value.text,
                        genderController.value.text,
                        picture,
                        serviceController.value.text);

                   // UserDatabase.db.insertUser(user);
                    //Navigator.push(context, MaterialPageRoute(builder: (context) => UsersList()));
                  }
                },
                child: Text('Save'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
